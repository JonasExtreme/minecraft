
import './App.css'
import Header from './components/header'
import Banner from './components/Banner'
import Sobre from './components/Sobre'
import Galeria from './components/Galeria'


function App() {

  return (

<div>
  <Header/>

  <div className="principal2">
  <Banner/>
  <Sobre/>
  <Galeria/>
  </div>

  </div>

  )
}

export default App

