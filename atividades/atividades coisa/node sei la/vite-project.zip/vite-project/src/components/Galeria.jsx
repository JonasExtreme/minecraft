export default function Galeria(){
    return(
        <section className="galeria">
            <h2>Galeria</h2>
            <img src="./leao1.jpeg"/>
            <img src="./leao2.jpeg"/>
            <img src="./leao3.jpeg"/>
            <img src="./leao4.jpeg"/>
        </section>
    )
}