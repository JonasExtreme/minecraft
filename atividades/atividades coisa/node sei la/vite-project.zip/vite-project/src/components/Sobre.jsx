export default function Sobre(){
    return(
        <section className="sobre">
            <li>Fala galera! Aqui vamos falar sobre o Leão da Ilha</li>
        </section>
    )
}