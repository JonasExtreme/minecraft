function Header(){
    return (
        <header>
            <h1>Página do Leão</h1>
            <h3>"Da ilha, és o Leão"</h3>
        </header>
    )
}

export default Header