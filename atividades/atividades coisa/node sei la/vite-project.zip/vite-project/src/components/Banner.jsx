export default function Banner(){
    return(
        <section className="banner">
            <img src="./avai1.png"/>
        </section>
    )
}