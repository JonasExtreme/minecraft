import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, FlatList, Text, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const App = () => {
  const [titulo, setTitulo] = useState('');
  const [ano, setAno] = useState('');
  const [local, setLocal] = useState('');
  const [descricao, setDescricao] = useState('');
  const [memorias, setMemorias] = useState([]);

  useEffect(() => {
    const carregarMemorias = async () => {
      const memoriaSalvas = await AsyncStorage.getItem('memorias');
      if (memoriaSalvas) {
        setMemorias(JSON.parse(memoriaSalvas));
      }
    };

    carregarMemorias();
  }, []);

  const adicionarMemoria = async () => {
    const novaMemoria = { titulo, ano, local, descricao };
    const novasMemorias = [...memorias, novaMemoria];
    setMemorias(novasMemorias);
    await AsyncStorage.setItem('memorias', JSON.stringify(novasMemorias));
    setTitulo('');
    setAno('');
    setLocal('');
    setDescricao('');
  };

  const renderItem = ({ item }) => (
    <View style={styles.memoriaItem}>
      <Text style={styles.titulo}>{item.titulo} ({item.ano})</Text>
      <Text>{item.local}</Text>
      <Text>{item.descricao}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Título"
        value={titulo}
        onChangeText={setTitulo}
        style={styles.input}
      />
      <TextInput
        placeholder="Ano"
        value={ano}
        onChangeText={setAno}
        style={styles.input}
        keyboardType="numeric"
      />
      <TextInput
        placeholder="Local"
        value={local}
        onChangeText={setLocal}
        style={styles.input}
      />
      <TextInput
        placeholder="Descrição"
        value={descricao}
        onChangeText={setDescricao}
        style={styles.input}
      />
      <Button title="Adicionar Memória" onPress={adicionarMemoria} />
      <FlatList
        data={memorias}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    padding: 10,
  },
  memoriaItem: {
    marginVertical: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  titulo: {
    fontWeight: 'bold',
  },
});

export default App;
