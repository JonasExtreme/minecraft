import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import {
  View,
  TextInput,
  Button,
  FlatList,
  Text,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';

const Stack = createNativeStackNavigator();

const HomeScreen = ({ navigation }) => {
  const [memorias, setMemorias] = useState([]);

  useEffect(() => {
    const carregarMemorias = async () => {
      const memoriaSalvas = await AsyncStorage.getItem('memorias');
      if (memoriaSalvas) {
        setMemorias(JSON.parse(memoriaSalvas));
      }
    };

    carregarMemorias();
  }, []);

  const renderItem = ({ item }) => (
    <View style={styles.memoriaItem}>
      <Text style={styles.titulo}>{item.titulo} ({item.ano})</Text>
      <Text>{item.local}</Text>
      <Text>{item.descricao}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Button title="Adicionar Memória" onPress={() => navigation.navigate('Adicionar Memória')} />
      <FlatList
        data={memorias}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
      />
    </View>
  );
};

const AddMemoryScreen = ({ navigation }) => {
  const [titulo, setTitulo] = useState('');
  const [ano, setAno] = useState('');
  const [local, setLocal] = useState('');
  const [descricao, setDescricao] = useState('');
  const [foto, setFoto] = useState(null);

  const adicionarMemoria = async () => {
    const novaMemoria = { titulo, ano, local, descricao, foto };
    const memoriaSalvas = await AsyncStorage.getItem('memorias');
    const novasMemorias = memoriaSalvas ? [...JSON.parse(memoriaSalvas), novaMemoria] : [novaMemoria];
    await AsyncStorage.setItem('memorias', JSON.stringify(novasMemorias));
    navigation.goBack();
  };

  const escolherFoto = async () => {
    let resultado = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!resultado.canceled) {
      setFoto(resultado.assets[0].uri);
    }
  };

  return (
    <View style={styles.container}>
      <TextInput placeholder="Título" value={titulo} onChangeText={setTitulo} style={styles.input} />
      <TextInput placeholder="Ano" value={ano} onChangeText={setAno} style={styles.input} keyboardType="numeric" />
      <TextInput placeholder="Cidade" value={local} onChangeText={setLocal} style={styles.input} />
      <TextInput placeholder="Descrição" value={descricao} onChangeText={setDescricao} style={styles.input} />
      <TouchableOpacity style={styles.button} onPress={escolherFoto}>
        <Text style={styles.buttonText}>Adicionar Foto</Text>
      </TouchableOpacity>
      {foto && <Image source={{ uri: foto }} style={styles.image} />}
      <Button title="Salvar Memória" onPress={adicionarMemoria} />
    </View>
  );
};

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Adicionar Memória" component={AddMemoryScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    padding: 10,
  },
  memoriaItem: {
    marginVertical: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  titulo: {
    fontWeight: 'bold',
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  image: {
    width: 100,
    height: 100,
    marginVertical: 10,
  },
});

export default App;
