export default function Galeria(){
    return(
        <div className="galeria">
            <img src="download.jpg"/>
            <img src="download.jpg"/>
            <img src="download.jpg"/>
            <img src="download.jpg"/>
            <img src="download.jpg"/>
            <img src="download.jpg"/>
        </div>
    )
}