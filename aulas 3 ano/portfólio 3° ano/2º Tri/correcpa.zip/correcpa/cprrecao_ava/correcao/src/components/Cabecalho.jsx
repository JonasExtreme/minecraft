export default function Cabecalho(){
    return(
        <header>
            <img src="./download.jpg"/>
        </header>
    )
}